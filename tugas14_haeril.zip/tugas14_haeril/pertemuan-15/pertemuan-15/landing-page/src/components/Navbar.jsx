function Navbar(){
    let title = "My Landing Page";

    return(
        <>
            <div>
                <h2>{title}</h2>
            </div>
        </>
    );
}

export default Navbar